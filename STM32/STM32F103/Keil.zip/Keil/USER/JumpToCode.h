#ifndef __JUMPTOCODE_H
#define __JUMPTOCODE_H

void Iap_Load_App(u32 AppAddr);

#endif

