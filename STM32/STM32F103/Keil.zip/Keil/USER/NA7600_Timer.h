#ifndef __NA7600_TIMER_H
#define __NA7600_TIMER_H

#include "stm32f10x.h"




void TIM3_Init(u16 arr, u16 psc);


#endif













