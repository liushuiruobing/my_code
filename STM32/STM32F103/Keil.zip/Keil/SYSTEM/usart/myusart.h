#ifndef __MYUSART_H
#define __MYUSART_H
#include "stdio.h"	
#include "sys.h" 

void uart_init(int Baud);

#endif


